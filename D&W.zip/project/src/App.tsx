import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Navigation } from '@/components/navigation';
import { CategorySection } from '@/components/category-section';
import { CartDrawer } from '@/components/ui/cart-drawer';
import { Footer } from '@/components/footer';
import { useCart } from '@/hooks/useCart';
import { products } from '@/data/products';
import { categories } from '@/data/categories';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [hoveredProduct, setHoveredProduct] = useState<number | null>(null);
  const {
    cartItems,
    isCartOpen,
    setIsCartOpen,
    addToCart,
    removeFromCart,
    updateQuantity,
    totalItems,
    totalPrice,
  } = useCart();

  // Simulate different products for each category
  const getCategoryProducts = (categoryId: string) => {
    return products.map(product => ({
      ...product,
      id: parseInt(`${categoryId}${product.id}`),
    }));
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation
        isMenuOpen={isMenuOpen}
        setIsMenuOpen={setIsMenuOpen}
        cartItemsCount={totalItems}
        onCartClick={() => setIsCartOpen(true)}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={updateQuantity}
        onRemove={removeFromCart}
        totalPrice={totalPrice}
      />

      {/* Hero Section */}
      <section className="pt-24 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl sm:text-6xl font-bold mb-6 animate-fade-in">
            Elevate Your Style
          </h2>
          <p className="text-lg text-muted-foreground mb-8 animate-slide-up">
            Discover the latest trends in fashion with D&W's exclusive collection
          </p>
          <Button size="lg" className="btn-animated btn-glow">
            Shop Now <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </section>

      {/* Category Sections */}
      {categories.map(category => (
        <CategorySection
          key={category.id}
          id={category.id}
          title={category.name}
          description={category.description}
          products={getCategoryProducts(category.id)}
          onAddToCart={addToCart}
          hoveredProduct={hoveredProduct}
          onHover={setHoveredProduct}
        />
      ))}

      <Footer />
    </div>
  );
}

export default App;