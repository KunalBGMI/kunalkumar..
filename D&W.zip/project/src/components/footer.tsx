import { MessageCircle, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Footer() {
  return (
    <footer className="bg-secondary mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About Section */}
          <div>
            <h3 className="text-lg font-semibold mb-4">About D&W</h3>
            <p className="text-muted-foreground">
              Discover the latest in fashion with D&W. We bring you curated collections
              that define style and elegance.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#new" className="text-muted-foreground hover:text-foreground transition-colors">
                  New Arrivals
                </a>
              </li>
              <li>
                <a href="#women" className="text-muted-foreground hover:text-foreground transition-colors">
                  Women's Collection
                </a>
              </li>
              <li>
                <a href="#men" className="text-muted-foreground hover:text-foreground transition-colors">
                  Men's Collection
                </a>
              </li>
              <li>
                <a href="#accessories" className="text-muted-foreground hover:text-foreground transition-colors">
                  Accessories
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-2">
              <li className="flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span className="text-muted-foreground">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="h-4 w-4" />
                <span className="text-muted-foreground">contact@dw-fashion.com</span>
              </li>
              <li className="flex items-center space-x-2">
                <MapPin className="h-4 w-4" />
                <span className="text-muted-foreground">123 Fashion St, NY 10001</span>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Connect With Us</h3>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="btn-animated btn-hover-raise">
                <a href="https://t.me/dwfashion" target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="h-6 w-6" />
                </a>
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} D&W Fashion. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}