import { Menu, X, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface NavigationProps {
  isMenuOpen: boolean;
  setIsMenuOpen: (isOpen: boolean) => void;
  cartItemsCount: number;
  onCartClick: () => void;
}

export function Navigation({
  isMenuOpen,
  setIsMenuOpen,
  cartItemsCount,
  onCartClick,
}: NavigationProps) {
  return (
    <nav className="fixed w-full bg-background/80 backdrop-blur-sm z-50 border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden btn-animated"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
            <h1 className="text-2xl font-bold ml-2">D&W</h1>
          </div>

          <div className="hidden lg:flex space-x-8">
            <NavLink href="#new">New Arrivals</NavLink>
            <NavLink href="#women">Women</NavLink>
            <NavLink href="#men">Men</NavLink>
            <NavLink href="#accessories">Accessories</NavLink>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="btn-animated btn-hover-raise relative"
            onClick={onCartClick}
          >
            <ShoppingBag className="h-6 w-6" />
            {cartItemsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground h-5 w-5 rounded-full text-xs flex items-center justify-center animate-fade-in">
                {cartItemsCount}
              </span>
            )}
          </Button>
        </div>
      </div>

      <div
        className={cn(
          "lg:hidden transition-all duration-300 ease-in-out overflow-hidden",
          isMenuOpen ? "max-h-64" : "max-h-0"
        )}
      >
        <div className="px-2 pt-2 pb-3 space-y-1">
          <MobileNavLink href="#new">New Arrivals</MobileNavLink>
          <MobileNavLink href="#women">Women</MobileNavLink>
          <MobileNavLink href="#men">Men</MobileNavLink>
          <MobileNavLink href="#accessories">Accessories</MobileNavLink>
        </div>
      </div>
    </nav>
  );
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      className="text-foreground/60 hover:text-foreground transition-colors duration-200 px-3 py-2 btn-hover-raise"
    >
      {children}
    </a>
  );
}

function MobileNavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      className="block px-3 py-2 text-base font-medium text-foreground/60 hover:text-foreground hover:bg-accent rounded-md transition-colors duration-200 btn-slide-in"
    >
      {children}
    </a>
  );
}