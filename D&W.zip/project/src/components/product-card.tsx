import { Product } from '@/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { ShoppingBag, ShoppingCart } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  isHovered: boolean;
  onHover: (id: number | null) => void;
  onAddToCart: (product: Product) => void;
}

export function ProductCard({
  product,
  isHovered,
  onHover,
  onAddToCart,
}: ProductCardProps) {
  return (
    <Card
      className={cn(
        "group overflow-hidden transition-all duration-300 hover:shadow-lg",
        isHovered ? "scale-105" : ""
      )}
      onMouseEnter={() => onHover(product.id)}
      onMouseLeave={() => onHover(null)}
    >
      <div className="aspect-square overflow-hidden relative">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
        />
        <div className="absolute bottom-4 left-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button
            className="flex-1 btn-animated btn-expand"
            onClick={() => onAddToCart(product)}
          >
            Add to Cart
            <ShoppingCart className="ml-2 h-4 w-4" />
          </Button>
          <Button
            className="btn-animated btn-expand"
            variant="secondary"
            onClick={() => {
              onAddToCart(product);
              // You can add immediate checkout logic here
            }}
          >
            Buy Now
          </Button>
        </div>
      </div>
      <div className="p-4">
        <h4 className="font-semibold">{product.name}</h4>
        <div className="flex justify-between items-center mt-2">
          <p className="text-muted-foreground">${product.price.toFixed(2)}</p>
          <Button
            variant="ghost"
            size="icon"
            className="btn-animated btn-hover-raise"
            onClick={() => onAddToCart(product)}
          >
            <ShoppingBag className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}