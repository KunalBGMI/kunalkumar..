import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/product-card';
import { Product } from '@/types';

interface CategorySectionProps {
  id: string;
  title: string;
  description: string;
  products: Product[];
  onAddToCart: (product: Product) => void;
  hoveredProduct: number | null;
  onHover: (id: number | null) => void;
}

export function CategorySection({
  id,
  title,
  description,
  products,
  onAddToCart,
  hoveredProduct,
  onHover,
}: CategorySectionProps) {
  return (
    <section id={id} className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">{title}</h2>
          <p className="text-muted-foreground">{description}</p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              isHovered={hoveredProduct === product.id}
              onHover={onHover}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>

        <div className="text-center mt-8">
          <Button className="btn-animated btn-glow">
            View All {title}
          </Button>
        </div>
      </div>
    </section>
  );
}