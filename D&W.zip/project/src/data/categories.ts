export const categories = [
  {
    id: 'new',
    name: 'New Arrivals',
    description: 'Latest fashion trends and styles'
  },
  {
    id: 'women',
    name: 'Women',
    description: 'Elegant women\'s collection'
  },
  {
    id: 'men',
    name: 'Men',
    description: 'Sophisticated men\'s fashion'
  },
  {
    id: 'accessories',
    name: 'Accessories',
    description: 'Complete your look'
  }
];