import { Product } from '@/types';

export const products: Product[] = [
  {
    id: 1,
    name: "Classic White Tee",
    price: 29.99,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&auto=format"
  },
  {
    id: 2,
    name: "Denim Jacket",
    price: 89.99,
    image: "https://images.unsplash.com/photo-1551537482-f2075a1d41f2?w=500&auto=format"
  },
  {
    id: 3,
    name: "Black Dress",
    price: 119.99,
    image: "https://images.unsplash.com/photo-1539008835657-9e8e9680c956?w=500&auto=format"
  },
  {
    id: 4,
    name: "Leather Boots",
    price: 159.99,
    image: "https://images.unsplash.com/photo-1520639888713-7851133b1ed0?w=500&auto=format"
  }
];